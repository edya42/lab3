/**
 * 
 */
package com.jsfdemo.bean;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.lang.reflect.Type;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.event.AbortProcessingException;
import javax.faces.event.ActionEvent;

import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;





public class UserBean {

	

	private String URLString ="http://37.139.23.174:8080/shopping-list-services/purchases/";
	
	private Map<String,  List<ListItem>> listItems;
	
	private String currentUser = "eduard";
	private String selectedList;
	private List<String> keys; 
	private ListItem newRecord = new ListItem();
	private String newKey;
	

	public UserBean() {
	}

	private void loadList() throws IOException {
		URL url = new URL(URLString+currentUser);
		URLConnection conn = url.openConnection();
		BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
		Gson gson = new GsonBuilder().create();
		Type listType = new TypeToken<Map<String,List<ListItem>>>() {}.getType();
		listItems = gson.fromJson(rd, listType);
		keys= new ArrayList<String>(listItems.keySet());
		selectedList=listItems.keySet().iterator().next();
		//currentList = listItems.get(listItems.keySet().iterator().next());
	}
	
	
	
	@PostConstruct
	public void init(){
	
		try{			
			loadList();
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	

	public void Save(ActionEvent event) throws IOException  {
		String url = URLString+currentUser;

		HttpClient client = new DefaultHttpClient();
		HttpPost post = new HttpPost(url);
			

	    // add header
	    post.setHeader("User-Agent", "test");

			
			
		Gson gson = new GsonBuilder().create();
		StringWriter sw = new StringWriter();
		gson.toJson(listItems, sw);
			
		StringEntity se = new StringEntity(sw.toString());
		se.setContentType("application/json");
		post.setEntity(se);
			
		client.execute(post);
	}
	
	public void deleteAction(ListItem li){
		listItems.get(selectedList).remove(li);
	}
	
	public void addAction(ListItem li){
		listItems.get(selectedList).add(li);
		newRecord = new ListItem();
	}
	
	public void addKey(){
		listItems.put(newKey, new ArrayList<ListItem>());
		keys= new ArrayList<String>(listItems.keySet());
		newKey = new String();
	}
	
	public String nullAll(){
		init();
		return "main";
	}
	
	public void Load(ActionEvent event)throws AbortProcessingException {
		try {
			loadList();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	
	public String getURLString() {
		return URLString;
	}

	public void setURLString(String uRLString) {
		URLString = uRLString;
	}

	public Map<String, List<ListItem>> getListItems() {
		return listItems;
	}

	public void setListItems(Map<String, List<ListItem>> listItems) {
		this.listItems = listItems;
	}

	public String getCurrentUser() {
		return currentUser;
	}

	public void setCurrentUser(String currentUser) {
		this.currentUser = currentUser;
	}

	public String getSelectedList() {
		return selectedList;
	}

	public void setSelectedList(String selectedList) {
		this.selectedList = selectedList;
	}

	public List<String> getKeys() {
		return keys;
	}

	public void setKeys(List<String> keys) {
		this.keys = keys;
	}

	public ListItem getNewRecord() {
		return newRecord;
	}

	public void setNewRecord(ListItem newRecord) {
		this.newRecord = newRecord;
	}

	public String getNewKey() {
		return newKey;
	}

	public void setNewKey(String newKey) {
		this.newKey = newKey;
	}
}
